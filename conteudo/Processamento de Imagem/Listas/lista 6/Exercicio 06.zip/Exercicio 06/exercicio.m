# Marcos Rodrigues - 14.2.4341
# Lista 06
pkg load image

img = imread('C:/Users/Aluno/Desktop/Exercicio 06/lenna.png');
#imshow(img);
# 01) Remover o ru�do com o Filtro Notch
#nImg = notchFilter(img, 40, 40, 40, 30);
#imshow(nImg, []);

# 02) Filtro Ideal, Filtro Butterworth e Filtro Gaussian
#nImg = filtroIdeal(img, 60, 25);
#imshow(nImg, []);
#nImg = butterworthMask (img, 60, 30, 20);
#figure; #imshow(nImg, []);
#nImg = gaussianNoise(img, 60, 40);
#imshow(nImg, []);

# 03) Filtro de Wiener
img = imread('C:/Users/Aluno/Desktop/Exercicio 06/ruido.png');
nImg = filtroWiener(img, 5, 200);
imshow(nImg, []);
